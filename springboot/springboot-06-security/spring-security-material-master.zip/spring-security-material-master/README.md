# Spring security教程案例素材（狂神说Java之SpringBoot教程集合版）

#### 介绍
狂神SpringBoot教程IDEA版中p34中用到的页面素材，学习Spring security

